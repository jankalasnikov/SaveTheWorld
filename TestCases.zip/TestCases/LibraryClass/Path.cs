﻿using System;
using System.Collections.Generic;
using System.Text;

namespace LibraryClass
{
    public class Path : IPath<double>
    {
        IList<IPoint1<double>> points;
        public Path(List<IPoint1<double>> point)
        {
            this.points = point;
        }
        public double CalculateTotalDistance() 
        {
            // Hint: Use the CalculateDistanceTo method (next exercise) on an internal collection of points

            // double a = (double)(nextPoint.X - currentPoint.X);
            // double b = (double)(nextPoint.Y - currentPoint.Y);

            // return Math.Sqrt(a * a + b * b);

            double total=0.0;

            if (points == null || points.Count < 2)
                return total;

            for(int i=1; i<points.Count; i++)
            {
                var previousPoint = points[i - 1];
                var currentPoint = points[i];

                var distancete = previousPoint.CalculateDistanceTo(currentPoint);
                total += distancete;
            }
            return total;


         //   double distance = Math.Sqrt(Math.Pow(nextPoint.X - currentPoint.X, 2) + Math.Pow(currentPoint.Y - nextPoint.Y, 2));

           // return distance;
        }
    }
}
