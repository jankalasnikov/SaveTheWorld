﻿using System;
using System.Collections.Generic;
using System.Text;

namespace LibraryClass
{
    public static class MathOperations 
    {
        /// <summary>
        /// Returns the distance of the current point to the next point using pythagoras equat
       // ion
/// </summary>
/// <param name="currentPoint"></param>
/// <param name="nextPoint"></param>
/// <returns></returns>
public static double CalculateDistanceTo(this IPoint1<double> currentPoint, IPoint1<double> nextPoint)
        {

            //   double a = (double)(nextPoint.X - currentPoint.X);
            // double b = (double)(nextPoint.Y - currentPoint.Y);

            // return Math.Sqrt(a * a + b * b);


            double distance = Math.Sqrt(Math.Pow(nextPoint.Y - currentPoint.X, 2) + Math.Pow(currentPoint.X - nextPoint.Y, 2));

            return distance;

            // TODO: Use the pythagoras equation to calculate the distance between two points.
            // You can use the System.Math class: https://msdn.microsoft.com/enus/library/system.math(v=vs.110).aspx to help with calculating square roots and power.
           
    }
}
}
