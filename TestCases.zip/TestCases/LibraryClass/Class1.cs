﻿using System;

namespace LibraryClass
{
    public class Class1
    {
    }
}
