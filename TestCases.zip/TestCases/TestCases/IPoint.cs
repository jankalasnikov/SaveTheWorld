﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TestCases
{
    
        public interface IPoint
        {
            /// <summary>
            /// Gets the x coordinate
            /// </summary>
            T X { get; }
            /// <summary>
            /// Gets the y coordinate
            /// </summary>
            T Y { get; }
        }
    }

