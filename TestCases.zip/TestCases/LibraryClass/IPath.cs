﻿using System;
using System.Collections.Generic;
using System.Text;

namespace LibraryClass
{
    public interface IPath<T>
    {
        /// <summary>
        /// Calculates the distance of the path
        /// </summary>
        /// <returns></returns>
        double CalculateTotalDistance();
    }
}
