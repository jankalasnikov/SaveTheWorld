﻿using System.Collections.Generic;
namespace LibraryClass
{
    public interface IPoint1<T>
    {
        /// <summary>
        /// Gets the x coordinate
        /// </summary>
        T X { get; }
        /// <summary>
        /// Gets the y coordinate
        /// </summary>
        T Y { get; }
    }
}